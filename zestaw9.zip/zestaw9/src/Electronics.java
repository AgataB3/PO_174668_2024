public class Electronics {
    public void turnOn(){
        System.out.println("Urządzenie włączone");
    }
}
