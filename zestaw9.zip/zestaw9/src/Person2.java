public record Person2(String imie, int wiek) {
    public Person2(String imie, int wiek) {
        this.imie = imie;
        if(wiek < 0){
            this.wiek = 0;
        }
        else this.wiek = wiek;
    }
}
