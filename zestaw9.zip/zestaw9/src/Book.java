import java.util.ArrayList;
import java.util.Objects;

public class Book {
    String title;
    String author;
    ArrayList<Double> reviews;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.reviews = new ArrayList<>();
    }

    public void addReview(double rating) {
        this.reviews.add(rating);
    }

    public void deleteReview(double rating) {
        this.reviews.remove(rating);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public ArrayList<Double> getReviews() {
        return reviews;
    }

    public void setReviews(ArrayList<Double> reviews) {
        this.reviews = reviews;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", reviews=" + reviews +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Book book)) return false;
        return Objects.equals(title, book.title) && Objects.equals(author, book.author);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, author);
    }
}
