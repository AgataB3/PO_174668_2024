import java.util.Objects;

public class Car2 {
    String make;
    String model;
    Engine engine;

    public Car2(String make, String model, Engine engine) {
        this.make = make;
        this.model = model;
        this.engine = engine;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Engine getEngine() {
        return engine;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    @Override
    public String toString() {
        return "Car2{" +
                "make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", engine=" + engine +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Car2 car2)) return false;
        return Objects.equals(make, car2.make) && Objects.equals(model, car2.model) && Objects.equals(engine, car2.engine);
    }

    @Override
    public int hashCode() {
        return Objects.hash(make, model, engine);
    }
}
