import java.util.ArrayList;
import java.util.HashMap;

public class Magazyn {
    private HashMap<Produkt, Integer> produkty;

    public Magazyn() {
        this.produkty = new HashMap<>();
    }

    public void dodajProdukt(Produkt produkt, int ilosc) {
        if(produkty.containsKey(produkt)) {
            produkty.put(produkt, produkty.get(produkt) + ilosc);
        }
        else{
            produkty.put(produkt, ilosc);
        }
        produkt.dodajDoMagazynu(ilosc);
    }

    public String getClass(String ok){
        return "Cześć jestem klasą Magazyn";
    }

    public void wyswietlAsortyment() {
        System.out.println("Asortyment magazynu:");
        for (Produkt produkt : produkty.keySet()) {
            Integer ilosc = produkty.get(produkt);
            System.out.println("Produkt: " + produkt.getNazwa() +
                    ", Cena: " + produkt.getCena() +
                    ", Ilość: " + ilosc);
        }
    }

    @Override
    public String toString() {
        return "Magazyn{" +
                "produkty=" + produkty +
                '}';
    }

    public HashMap<Produkt, Integer> getProdukty() {
        return produkty;
    }

    public void setProdukty(HashMap<Produkt, Integer> produkty) {
        this.produkty = produkty;
    }
}
