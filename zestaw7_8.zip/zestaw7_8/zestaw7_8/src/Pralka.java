public class Pralka extends UrzadzenieElektroniczne{
    private String marka;
    public Pralka(String nazwa, double cena, int iloscNaMagazynie, String marka) {
        super(nazwa, cena, iloscNaMagazynie);
        this.marka = marka;
    }

    public void napraw(){
        System.out.println("Pralka naprawiona.");
    }
    public void uzyj(){
        System.out.println("Pralka została użyta.");
    }
    public void zepsuj(){
        System.out.println("Pralka zepsuta.");
    }
    public void wlacz(){
        System.out.println("Pralka włączona.");
    }
    public void wylacz(){
        System.out.println("Pralka wyłączona.");
    }

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        if(marka == null || marka.isEmpty()){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.marka = marka;
        }
    }
}
