public class ProduktPrzemyslowy extends Produkt {
    public ProduktPrzemyslowy(String nazwa, double cena, int iloscNaMagazynie) {
        super(nazwa, cena, iloscNaMagazynie);
    }
}
