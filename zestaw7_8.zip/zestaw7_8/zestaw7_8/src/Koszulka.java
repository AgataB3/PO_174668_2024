public class Koszulka extends Ubranie{
    private String marka;
    public Koszulka(String nazwa, double cena, int iloscNaMagazynie, String marka) {
        super(nazwa, cena, iloscNaMagazynie);
        this.marka = marka;
    }
    public void wypierz(){
        System.out.println("Koszulka została wyprana.");
    }
    public void zaloz(){
        System.out.println("Koszulka została założona.");
    }
    public void wyprasuj(){
        System.out.println("Koszulka została wyprasowana.");
    }
    public void wysusz(){
        System.out.println("Koszulka została wysuszona.");
    }
    public void zniszcz(){
        System.out.println("Koszulka została zniszczona.");
    }

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        if(marka == null || marka.isEmpty()){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.marka = marka;
        }
    }
}
