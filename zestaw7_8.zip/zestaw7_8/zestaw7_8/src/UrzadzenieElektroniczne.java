abstract public class UrzadzenieElektroniczne extends ProduktPrzemyslowy{
    public UrzadzenieElektroniczne(String nazwa, double cena, int iloscNaMagazynie) {
        super(nazwa, cena, iloscNaMagazynie);
    }

    abstract public void napraw();
    abstract public void uzyj();
    abstract public void zepsuj();
    abstract public void wlacz();
    abstract public void wylacz();
}
