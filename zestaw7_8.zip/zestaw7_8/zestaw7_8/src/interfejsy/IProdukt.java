package interfejsy;

public interface IProdukt {
    String toString();
    String getClass(String ok);
    int hashCode();
    boolean equals(Object o);
    void dodajDoMagazynu(int ilosc);
    void usunZMagazynu(int ilosc);
    String getNazwa();
    void setNazwa(String nazwa);
    double getCena();
    void setCena(double cena);
    int getIloscNaMagazynie();
    void setIloscNaMagazynie(int iloscNaMagazynie);

    //metody domyslne
    default void obnizCene(double procent) {
        if (procent <= 0 || procent > 100) {
            throw new IllegalArgumentException("Procent musi być z zakresu (0, 100].");
        }
        setCena(getCena() * (1 - procent / 100));
        System.out.println("Cena produktu " + getNazwa() + " została obniżona o " + procent + "%.");
    }

    default boolean czyDostepny() {
        return getIloscNaMagazynie() > 0;
    }
}
