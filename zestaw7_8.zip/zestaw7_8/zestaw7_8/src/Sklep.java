import java.util.ArrayList;
import java.time.LocalDate;

public class Sklep {
    private String nazwaSklepu;
    private LocalDate dataPowstania;
    private Magazyn magazynSklepu;

    public Sklep(String nazwaSklepu, LocalDate dataPowstania, Magazyn magazyn) {
        if (dataPowstania.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Data powstania nie może być datą z przyszłości.");
        }
        this.nazwaSklepu = nazwaSklepu;
        this.dataPowstania = dataPowstania;
        this.magazynSklepu = magazyn;
    }

    public void dodajProdukt(Produkt produkt, int ilosc){
        magazynSklepu.dodajProdukt(produkt, ilosc);
    }

    @Override
    public String toString() {
        return "Sklep{" +
                "nazwaSklepu='" + nazwaSklepu + '\'' +
                ", dataPowstania=" + dataPowstania +
                ", magazynSklepu=" + magazynSklepu +
                '}';
    }

    public String getClass(String ok){
        return "Cześć jestem klasą Sklep";
    }

    public void wyswietlOferty() {
        System.out.println("Oferta sklepu: " + nazwaSklepu + " (Data powstania: " + dataPowstania + ")");
        magazynSklepu.wyswietlAsortyment();
    }

    public Produkt wyszukajProduktu(String nazwa){
        for(Produkt produkt :  magazynSklepu.getProdukty().keySet()){
            if(produkt.getNazwa().equals(nazwa)) return produkt;
        }
        return null;
    }

    public void zakupy(String nazwa, int ilosc, KoszykZakupowy koszyk){
        Produkt produkt = wyszukajProduktu(nazwa);
        if(produkt != null){
            if(produkt.getIloscNaMagazynie() >= ilosc){
                koszyk.dodajProdukt(produkt, ilosc);
                produkt.usunZMagazynu(ilosc);
            }
        }
    }

    public String getNazwaSklepu() {
        return nazwaSklepu;
    }

    public void setNazwaSklepu(String nazwaSklepu) {
        if(nazwaSklepu == null || nazwaSklepu.isEmpty()){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.nazwaSklepu = nazwaSklepu;
        }
    }

    public LocalDate getDataPowstania() {
        return dataPowstania;
    }

    public void setDataPowstania(LocalDate dataPowstania) {
        if(dataPowstania == null || dataPowstania.isAfter(LocalDate.now())){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else{
            this.dataPowstania = dataPowstania;
        }
    }

    public Magazyn getMagazynSklepu() {
        return magazynSklepu;
    }

    public void setMagazynSklepu(Magazyn magazynSklepu) {
        if(magazynSklepu == null){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.magazynSklepu = magazynSklepu;
        }
    }
}
