import java.util.ArrayList;
import java.util.Objects;

public class Klient extends Osoba{
    private ArrayList<Zamowienie> listaZamowien;
    private Adres adres;

    public Klient(String imie, String nazwisko, Adres adres) {
        super(imie, nazwisko);
        this.listaZamowien = new ArrayList<>();
        this.adres = adres;
    }

    public void dodajZamowienie(Zamowienie z) {
        listaZamowien.add(z);
    }

    public String getClass(String ok){
        return "Cześć jestem klasą Klient";
    }

    @Override
    public String toString() {
        return "Klient{" +
                "listaZamowien=" + listaZamowien +
                ", adres=" + adres +
                '}';
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(adres);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Klient klient = (Klient) o;
        return super.equals(o) && Objects.equals(adres, klient.adres);
    }

    public void wyswietlHistorieZamowien(){
        int i = 1;
        for(Zamowienie z : listaZamowien){
            System.out.println("Zamowienie "+i);
            z.wyswietlZamowienie();
            i++;
        }
    }
    public double obliczLacznyKosztZamowien(){
        double koszt = 0;
        for(Zamowienie z : listaZamowien){
            KoszykZakupowy k = z.getKoszykZakupowy();
            koszt += k.obliczCalkowitaWartosc();
        }
        return koszt;
    }

    public Adres getAdres() {
        return adres;
    }

    public void setAdres(Adres adres) {
        if(adres == null){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.adres = adres;
        }
    }

    public ArrayList<Zamowienie> getListaZamowien() {
        return listaZamowien;
    }

    public void setListaZamowien(ArrayList<Zamowienie> listaZamowien) {
        if(listaZamowien == null || listaZamowien.isEmpty()){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.listaZamowien = listaZamowien;
        }
    }
}
