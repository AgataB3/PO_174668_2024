public class Banan extends Owoc{
    private String firma;
    public Banan(String nazwa, double cena, int iloscNaMagazynie, String firma) {
        super(nazwa, cena, iloscNaMagazynie);
        this.firma = firma;
    }

    @Override
    public void smak() {
        System.out.println("Banan smakuje słodko i soczyście.");
    }

    @Override
    public void umyj() {
        System.out.println("Banan został umyty.");
    }

    @Override
    public void zjedz() {
        System.out.println("Zjadłeś banana.");
    }

    public String getFirma() {
        return firma;
    }

    public void setFirma(String firma) {
        if(firma == null || firma.isEmpty()){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.firma = firma;
        }
    }
}
