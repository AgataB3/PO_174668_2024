public class ProduktSpozywczy extends Produkt{
    public ProduktSpozywczy(String nazwa, double cena, int iloscNaMagazynie) {
        super(nazwa, cena, iloscNaMagazynie);
    }
}
