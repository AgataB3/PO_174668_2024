public class KlientIndywidualny extends Klient{
    public final String PESEL = "2319084563";

    public KlientIndywidualny(String imie, String nazwisko, Adres adres) {
        super(imie, nazwisko, adres);
    }
}
