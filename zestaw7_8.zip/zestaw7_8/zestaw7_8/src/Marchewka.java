public class Marchewka extends Warzywo{
    private String firma;
    public Marchewka(String nazwa, double cena, int iloscNaMagazynie, String firma) {
        super(nazwa, cena, iloscNaMagazynie);
        this.firma = firma;
    }

    @Override
    public void smak(){
        System.out.println("Marchewka ma słodki smak.");
    }
    public void umyj(){
        System.out.println("Umyłeś marchewkę");
    }
    public void zjedz(){
        System.out.println("Zjadłeś marchewkę");
    }

    public String getFirma() {
        return firma;
    }

    public void setFirma(String firma) {
        if(firma == null || firma.isEmpty()){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.firma = firma;
        }
    }
}
