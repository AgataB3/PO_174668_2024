public class Main {
    public static void main(String[] args) {
        System.out.println("Zadanie 1:");
        BookDT0 book1 = new BookDT0("Laboratorium", "Marek Kowalski", 34.90, 2022);
        BookDT0 book2 = new BookDT0("Słoneczny teatr", "Alicja Podkowska", 35.90, 2019);
        BookDT0 book3 = new BookDT0("Tan", "Urszula Piotrowska", 32.95, 2023);

        System.out.println(book1);
        System.out.println(book2);
        System.out.println(book3);

        System.out.println("Zadanie 2:");
        Address adres1 = new Address("Warszawska", "14b", "13-412", "Olsztyn");
        Person person1 = new Person("Agnieszka", "Szczęsna", adres1);
        System.out.println(person1);

        System.out.println("Zadanie 6:");
        Car car1 = new Car("Opel", "U5", 30);
        System.out.println(car1);
        System.out.println(car1.fuelCost(6.90, 200));

        System.out.println("Zadanie 9:");
        Person2 osoba1 = new Person2("Jan", -9);
        Person2 osoba2 = new Person2("Zdzisław", 60);
        System.out.println(osoba1);
        System.out.println(osoba2);

        System.out.println("Zadanie 10:");
        BankAccount konto1 = new BankAccount("9034832429");
        BankAccount konto2 = new BankAccount("9034832430", "90");
        System.out.println(konto1);
        System.out.println(konto2);

        System.out.println("Zadanie Złożone pola w klasie 1:");
        Book ksiazka1 = new Book("Piaski", "Andrzej Gracz");
        ksiazka1.addReview(9);
        ksiazka1.addReview(6);
        ksiazka1.addReview(7);
        ksiazka1.addReview(3);
        ksiazka1.deleteReview(3);
        System.out.println(ksiazka1.toString());

        FantasyBook ksiazkaFantasy = new FantasyBook("Czarodzieje z Olsztyna", "Henryk Polak", "Czarodzieje");
        ksiazkaFantasy.addReview(10);
        System.out.println(ksiazkaFantasy.toString());
        System.out.println(ksiazkaFantasy.getReviews());
        System.out.println(ksiazka1.equals(ksiazkaFantasy));
        System.out.println(ksiazka1.hashCode());

        System.out.println("Zadanie Pola, metody, klasy finalne 5:");
        Electronics elektronika = new Electronics();
        Television telewizja = new Television();
        elektronika.turnOn();
        telewizja.turnOn();

        System.out.println("Zadanie Pola, metody, klasy finalne 12:");
        ImmutableBook ksiazkaImmutable = new ImmutableBook("Róża", "Katarzyna Wiśniewska", "9128412");
        System.out.println(ksiazkaImmutable.toString());
    }
}