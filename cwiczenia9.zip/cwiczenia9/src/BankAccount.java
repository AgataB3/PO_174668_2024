public record BankAccount(String numerKonta, String saldo) {
    public BankAccount(String numerKonta) {
        this(numerKonta, "0");
    }
}
