public class Television extends Electronics{
    public void turnOn(){
        System.out.println("Telewizja została włączona");
    }
}
