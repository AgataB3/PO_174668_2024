public record BookDT0(String title, String author, double price, int yearOfPublication) {
}
