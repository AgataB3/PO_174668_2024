public class KlientFirmowy extends Klient{
    private final String NIP = "9012348943";
    private final String REGON = "908321456";

    public KlientFirmowy(String imie, String nazwisko, Adres adres) {
        super(imie, nazwisko, adres);
    }
}
