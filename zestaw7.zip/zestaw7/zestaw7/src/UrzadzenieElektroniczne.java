abstract public class UrzadzenieElektroniczne {
    abstract public void napraw();
    abstract public void uzyj();
    abstract public void zepsuj();
    abstract public void wlacz();
    abstract public void wylacz();

}
