public class Banan extends ProduktSpozywczy{
    public Banan(String nazwa, double cena, int iloscNaMagazynie) {
        super(nazwa, cena, iloscNaMagazynie);
    }
}
