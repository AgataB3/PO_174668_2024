package interfejsy;

public interface IAdres {
    String getClass(String ok);
    String toString();
    boolean przed(int kodPocztowy1, int kodPocztowy2);
    String getUlica();
    void setUlica(String ulica);
    String getNumerDomu();
    void setNumerDomu(String numerDomu);
    int getNumerMieszkania();
    void setNumerMieszkania(Integer numerMieszkania);
    String getMiasto();
    void setMiasto(String miasto);
    int getKodPocztowy();
    void setKodPocztowy(Integer kodPocztowy);
}
