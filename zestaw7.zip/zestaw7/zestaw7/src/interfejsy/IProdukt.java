package interfejsy;

public interface IProdukt {
    String toString();
    String getClass(String ok);
    int hashCode();
    boolean equals(Object o);
    void dodajDoMagazynu(int ilosc);
    void usunZMagazynu(int ilosc);
    String getNazwa();
    void setNazwa(String nazwa);
    double getCena();
    void setCena(double cena);
    int getIloscNaMagazynie();
    void setIloscNaMagazynie(int iloscNaMagazynie);
}
