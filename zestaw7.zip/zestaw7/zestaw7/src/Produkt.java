import interfejsy.IProdukt;

import java.util.Objects;

public class Produkt implements IProdukt {

    private String nazwa;
    private double cena;
    private int iloscNaMagazynie;

    public Produkt(String nazwa, double cena, int iloscNaMagazynie) {
        this.nazwa = nazwa;
        this.cena = cena;
        this.iloscNaMagazynie = iloscNaMagazynie;
    }

    @Override
    public String toString() {
        return "Produkt{" +
                "nazwa='" + nazwa + '\'' +
                ", cena=" + cena +
                ", iloscNaMagazynie=" + iloscNaMagazynie +
                '}';
    }

    public String getClass(String ok){
        return "Cześć jestem klasą Produkt";
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Produkt produkt = (Produkt) o;
        return Double.compare(cena, produkt.cena) == 0 && Objects.equals(nazwa, produkt.nazwa);
    }
    /*
    public void wyswietlInformacje(){
        System.out.println("Nazwa: " + nazwa + " Cena: " + cena + " Ilość na magazynie: "+ iloscNaMagazynie);
    }
    */

    public void dodajDoMagazynu(int ilosc){
        iloscNaMagazynie += ilosc;
    }

    public void usunZMagazynu(int ilosc){
        if(iloscNaMagazynie-ilosc > 0){
            iloscNaMagazynie -= ilosc;
        }
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        if(nazwa == null || nazwa.isEmpty()){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.nazwa = nazwa;
        }
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        if(cena < 0){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.cena = cena;
        }
    }

    public int getIloscNaMagazynie() {
        return iloscNaMagazynie;
    }

    public void setIloscNaMagazynie(int iloscNaMagazynie) {
        if(iloscNaMagazynie < 0){
            throw new IllegalArgumentException("Niepoprawne dane.");
        }
        else {
            this.iloscNaMagazynie = iloscNaMagazynie;
        }
    }
}
