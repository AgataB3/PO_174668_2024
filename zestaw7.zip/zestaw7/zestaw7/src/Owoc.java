abstract public class Owoc {
    public abstract String smak();
    public abstract void umyj();
    public abstract void zjedz();
}
