abstract public class Ubranie {
    abstract public void wypierz();
    abstract public void zaloz();
    abstract public void wyprasuj();
    abstract public void wysusz();
    abstract public void zniszcz();
}
